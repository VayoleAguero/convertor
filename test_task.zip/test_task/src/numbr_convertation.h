#include <stdio.h>
#include <inttypes.h>

void print_number_in_base(int64_t number, int base);
void print_number_in_architecture(int64_t number, int architecture);
void print_number_in_order(int64_t number, int endian);