#include <stdio.h>
#include <stdarg.h>
#include <inttypes.h>

int64_t and_operation(int64_t num_args, ...) ;
int64_t or_operation(int64_t num_args, ...);
int64_t xor_operation(int64_t num1, int64_t num2);
int64_t nor_operation(int64_t num1);